# README #

This is the official repository of the R package SELECT - Selected Events Linked by Evolutionary Conditions across human Tumors - a methodology to infer evolutionary inter-dependencies between functional alterations in cancer.

### What is this repository for? ###

* SELECT is a package for inferring evolutionary dependencies between functional alterations in cancer starting from patterns of alteration occurrences in large tumor sample cohorts.
* Last Version: 1.6.4


### How To ###

* Summary of set up

``` r
install.packages("devtools")
devtools::install_github("CSOgroup/select")
```

* How to use
	- Check the introduction fom vignettes folder or the website.
	- Also refere to *methods section* of papers to know the best way to apply the method.

### Citation ###

If you use this tool, please cite the papers

- Mina, M., Iyer, A., Tavernari, D., Raynaud, F., & Ciriello, G. (2020). [Discovering functional evolutionary dependencies in human cancers](https://www.nature.com/articles/s41588-020-0703-5) Nature Genetics, 52(11), 1198-1207. 

- Mina, Marco and Raynaud, Franck and Tavernari, Daniele and Battistello, Elena and Sungalee, Stephanie and Saghafinia, Sadegh and Laessle, Titouan and Sanchez-Vega, Francisco and Schultz, Nikolaus and Oricchio, Elisa and Ciriello, G. (2017). [Conditional selection of genomic alterations dictates cancer evolution and oncogenic dependencies.](https://www.cell.com/cancer-cell/fulltext/S1535-6108(17)30261-1) Cancer cell, 32(2), 155-168.

### Contribution guidelines ###

- SELECT was originally developed by **Marco Mina** at the University of Lausanne, Switzerland.
- SELECT is currently maintained by Arvind Iyer and memeber of the Computational Systems Oncology lab (CSO) at the University of Lausanne (Unil), Switzerland.

### Who do I talk to? ###

* For any bugs or feature support in using SELECT, please use the [issue tracker][issue-tracker].
* For any other question related to SELECT, please contact Giovanni Ciriello (giovanni.ciriello@unil.ch).


[issue-tracker]: https://github.com/CSOgroup/select/issues
[issue-tracker]: https://github.com/CSOgroup/select/issues